import java.util.Scanner;

public class Exercicio {

    public static Scanner leitor = new Scanner(System.in);

    public static void main(String[] args) {

        int value;

        System.out.print("\n\n=+=+=+=+=+=SISTEMA INCIADO=+=+=+=+=+=\n\nInforme um exercicio (0 para encerrar): ");
        value = leitor.nextInt();

        switch (value) {
            case 0:
                System.out.println("\nSistema encerrado.\n");
                break;
            case 1:
                ex01();
                break;
            case 2:
                ex02();
                break;
            case 3:
                ex03();
                break;
            case 4:
                ex04();
                break;
            case 5:
                ex05();
                break;
            case 6:
                ex06();
                break;
            case 7:
                ex07();
                break;
            case 8:
                ex08();
                break;
            case 9:
                ex09();
                break;
            case 10:
                ex10();
                break;
            case 11:
                ex11();
                break;
            case 12:
                ex12();
                break;
            default:
                System.out.println("\nValor Invalido.\n");
                main(args);
                break;
        }

    }

    public static void ex01() {

        int numero;
        System.out.println("\n");
        System.out.print("Informe um numero: ");
        numero = leitor.nextInt();

        if (numero > 10) {
            System.out.println("O numero " + numero + " é maior que 10");
        } else if (numero <= 10) {
            System.out.println("O numero " + numero + " é menor ou igual a 10");
        } else {
            System.out.println("Valor invalido");
        }
        System.out.println("\n");
    }

    public static void ex02() {

        int numero1, numero2, resultado;
        System.out.println("\n");
        System.out.print("Informe um numero: ");
        numero1 = leitor.nextInt();
        System.out.print("Informe outro numero: ");
        numero2 = leitor.nextInt();

        resultado = numero1 + numero2;
        System.out.print("A soma dos valores é: " + resultado);
        System.out.println("\n");
    }

    public static void ex03() {

        int numeroA, numeroB;
        System.out.println("\n");
        System.out.print("Informe valor A: ");
        numeroA = leitor.nextInt();
        System.out.print("Informe valor B: ");
        numeroB = leitor.nextInt();

        if (numeroA > numeroB) {
            System.out.println("O valor A: " + numeroA + " é maior que o valor B: " + numeroB);
        } else if (numeroA < numeroB) {
            System.out.println("O valor B: " + numeroB + " é maior que o valor A: " + numeroA);
        } else {
            System.out.println("Os numeros não podem ser iguais");
        }

        System.out.println("\n");
    }

    public static void ex04() {

        int numero1, numero2, soma, subt, mult, divi;
        System.out.println("\n");
        System.out.print("Informe um numero: ");
        numero1 = leitor.nextInt();
        System.out.print("Informe outro numero: ");
        numero2 = leitor.nextInt();
        System.out.println("\n");

        soma = numero1 + numero2;
        System.out.print("A soma dos valores é: " + soma);
        System.out.println("\n");

        subt = numero1 - numero2;
        System.out.print("A subtração dos valores é: " + subt);
        System.out.println("\n");

        mult = numero1 * numero2;
        System.out.print("A multiplicação dos valores é: " + mult);
        System.out.println("\n");

        divi = numero1 / numero2;
        System.out.print("A divisão dos valores é: " + divi);
        System.out.println("\n");
    }

    public static void ex05() {

        int numeroA, numeroB, saveA, saveB;
        System.out.println("\n");
        System.out.print("Informe valor A: ");
        numeroA = leitor.nextInt();
        System.out.print("Informe valor B: ");
        numeroB = leitor.nextInt();

        System.out.println("");
        System.out.println("Valor A: " + numeroA + "\nValor B: " + numeroB);
        System.out.println("");

        saveA = numeroA;
        saveB = numeroB;
        numeroB = saveA;
        numeroA = saveB;

        System.out.println("Inversão efetuada.");
        System.out.println("");

        System.out.println("Valor A: " + numeroA + "\nValor B: " + numeroB);
        System.out.println("\n");
    }

    public static void ex06() {

        int C, F;
        System.out.println("\n");
        System.out.print("Informe uam temperatura em Celsius: ");
        C = leitor.nextInt();
        System.out.println("");

        F = (9 * C + 160) / 5;
        System.out.print("O equivalente em Farenheit é: " + F);
        System.out.println("\n");
    }

    public static void ex07() {
        System.out.print("\n\nInforme um valor inteiro que esteja entre 100 e 200: ");
        int valor = leitor.nextInt();

        if (valor < 100 || valor > 200) {
            System.out.println("Valor Invalido!");
            ex07();
        } else {
            System.out.println("Valor entre 100 e 200\n\n");
        }

    }

    public static void ex08() {
        System.out.print("\n\nInforme um valor: ");
        int valor = leitor.nextInt();

        if (valor >= 50) {
            System.out.println("\nO valor é maior ou igual a 50.\n\n");
        } else {
            System.out.println("\nO valor é menor que 50.\n");
        }

    }

    public static void ex09() {

        int numeroA, numeroB;
        System.out.println("\n");
        System.out.print("Informe valor A: ");
        numeroA = leitor.nextInt();
        System.out.print("Informe valor B: ");
        numeroB = leitor.nextInt();

        if (numeroA == numeroB) {
            System.out.println("\nOs valores " + numeroA + " e " + numeroB + " são iguais.\n");
        } else if (numeroA > numeroB) {
            System.out.println("\nOs valores são diferentes e " + numeroA + " é maior que " + numeroB + ".\n");
        } else {
            System.out.println("\nOs valores são diferentes e " + numeroB + " é maior que " + numeroA + ".\n");
        }

    }

    public static void ex10() {
        System.out.print("\n\nInforme um valor inteiro que esteja entre 1 e 50: ");
        int valor = leitor.nextInt();

        if (valor < 1 || valor > 50) {
            System.out.println("Valor Invalido!");
            ex10();
        } else {
            while (valor <= 50) {
                System.out.println("valor: " + valor);
                valor++;
            }
        }
        System.out.println("\n");

    }

    public static void ex11() {

        System.out.print("\n\nDigite o primeiro termo (a1):");
        int a1 = leitor.nextInt();

        System.out.print("Digite o valor de n:");
        int n = leitor.nextInt();

        System.out.print("Digite a razão (r):");
        int r = leitor.nextInt();

        int an = a1 + (n - 1) * r;

        System.out.println("O " + n + "º termo da progressão aritmética é: " + an + "\n\n");

    }

    public static void ex12() {

        System.out.print("\n\nDigite o raio do cilindro:");
        double raio = leitor.nextDouble();

        System.out.print("Digite a altura do cilindro:");
        double altura = leitor.nextDouble();

        double volume = 3.14 * Math.pow(raio, 2) * altura;

        System.out.println("O volume do cilindro é: " + volume + "\n\n");
    }

}