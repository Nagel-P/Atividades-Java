import java.util.Scanner;

public class Aula02 {
    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);
        int dificuldade;

        System.out.println("\n");
        System.out.println("Qual o nivel de dificuldade até agora?");
        System.out.println("1 FACIL, 2 MEDIO, 3 DIFICIL");
        System.out.print("Informe: ");

        dificuldade = leitor.nextInt();

        if (dificuldade == 1) {
            System.out.println("GG EZ!");
        } else if (dificuldade == 2) {
            System.out.println("MEDIANO");
        } else if (dificuldade == 3) {
            System.out.println("HARDCORE MERMÃO");
        } else {
            System.out.println("VALOR INVALIDO OTARIO.");
        }
        System.out.println("\n");

        Scanner leitor2 = new Scanner(System.in);
        int avaliacao;

        System.out.println("Qual o nivel de dificuldade até agora?");
        System.out.println("1 FACIL, 2 MEDIO, 3 DIFICIL");
        System.out.print("Informe: ");

        avaliacao = leitor2.nextInt();

        switch (avaliacao) {
            case 1:
                System.out.println("GG EZ!");
                break;
            case 2:
                System.out.println("MEDIANO");
                break;
            case 3:
                System.out.println("HARDCORE MERMÃO");
                break;
            default:
                System.out.println("INVALIDO");
                break;
        }
        System.out.println("\n");
    }
}