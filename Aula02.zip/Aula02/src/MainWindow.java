import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainWindow {
    public static void main(String[] args) {
        // Criar uma janela Swing
        JFrame frame = new JFrame("Minha Janela");
        // Configurar o tamanho da janela
        frame.setSize(600, 100);

        // Configurar o comportamento padrão ao fechar a janela
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Criar um JPanel para conter a pergunta
        JPanel panel = new JPanel();
        // Configurar o layout do painel
        panel.setLayout(new BorderLayout());
        // Adicionar a pergunta ao painel
        JLabel pergunta = new JLabel(
                "Meu pai é seu pai, minha mãe é sua mãe, mas eu não sou você nem seu irmão, quem eu sou?");
        panel.add(pergunta, BorderLayout.CENTER);

        // Adicionar o JPanel à janela
        frame.add(panel, BorderLayout.NORTH);

        // Criar um JTextArea para permitir que o usuário escreva texto
        JTextArea textArea = new JTextArea();

        // Adicionar um KeyListener ao JTextArea para detectar quando Enter é
        // pressionado
        textArea.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                // Verificar se a tecla pressionada é Enter
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    // Verificar se o texto no JTextArea é "SerAph#812"
                    if (textArea.getText().trim().equalsIgnoreCase("Irmã")) {
                        // Fechar a janela atual
                        frame.dispose();
                        // Abrir uma nova janela com a mensagem
                        JFrame novaJanela = new JFrame("Nova Janela");
                        novaJanela.setLocationRelativeTo(null); // Centralizar a nova janela na tela
                        JLabel mensagem = new JLabel("Nice, resolveu o enigma.");
                        novaJanela.getContentPane().add(mensagem);
                        novaJanela.setSize(600, 100);
                        novaJanela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        novaJanela.setVisible(true);
                    }
                }
            }
        });

        // Adicionar o JTextArea à janela
        frame.add(textArea, BorderLayout.CENTER);

        // Exibir a janela
        frame.setVisible(true);
    }
}