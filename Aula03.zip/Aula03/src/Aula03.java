import java.util.Scanner;

public class Aula03 {

    public static Scanner leitor = new Scanner(System.in);

    public static void main(String[] args) {

        int exemplo;

        System.out.print("\n\nInforme um exemplo\n(0 | Encerrar) (1 | For) (2 | While) (3 | DoWhile) (4 | Vetor): ");
        exemplo = leitor.nextInt();

        switch (exemplo) {
            case 0:
                System.out.println("O programa sera finalizado.");
                break;
            case 1:
                exemploFor();
                break;
            case 2:
                exemploWhile();
                break;
            case 3:
                exemploDoWhile();
                break;
            case 4:
                exemploVetor();
                break;
            default:
                System.out.println("Valor não operavel!");
                main(args);
                break;
        }

    }

    public static void exemploFor() {

        System.out.print("\n\nInforme um valor inteiro para receber sua tabuada: ");
        int valor = leitor.nextInt();

        for (int bolinho = 1; bolinho <= 10; bolinho++) {
            System.out.println("\n" + valor + "x" + bolinho + "=" + (valor * bolinho));

        }

    }

    public static void exemploWhile() {
        System.out.print("\n\nInforme um valor inteiro, ele sera somado até 100: ");
        int valor = leitor.nextInt();

        if (valor > 100) {
            System.out.println("Valor é mairo que 100.");
        }

        while (valor <= 100) {
            System.out.println("valor atual: " + valor);
            valor++;
        }
        System.out.println("\n");
    }

    public static void exemploDoWhile() {
        System.out.print("\n\nInforme um valor inteiro que esteja entre 100 e 200: ");
        int valor = leitor.nextInt();
        System.out.println("todos os valores entre este e numero e 200 serão mostrados");

        if (valor < 100 || valor > 200) {
            exemploDoWhile();
        }

        while (valor <= 200) {

            if (valor % 2 == 0) {
                System.out.println("valor atual: " + valor);
            }
            valor++;
        }
    }

    public static void exemploVetor() {

        int[] vetor = new int[5];
        int[] dobro = new int[5];
        System.out.println("\n");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("Informe o valor da posição " + i + " do vetor:");
            vetor[i] = leitor.nextInt();
            dobro[i] = vetor[i] * 2;
        }
        System.out.print("\nvetor original: ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("[" + vetor[i] + "]");
        }
        System.out.print("\nvetor dobrado: ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("[" + dobro[i] + "]");
        }
        System.out.println("\n\n");
    }
}