import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

public class Pacman extends JFrame implements KeyListener {
    // Constantes para representar os caracteres do tabuleiro
    private static final char PACMAN_CHAR = 'P';
    private static final char EMPTY_CHAR = '.';
    private static final char POINT_CHAR = '*';
    private static final char WALL_CHAR = '#'; // Caractere para representar a parede do tabuleiro
    private static final char GHOST_CHAR = 'G';

    // Dimensões do tabuleiro
    private static final int ROWS = 10;
    private static final int COLS = 10;

    // Posições iniciais do Pac-Man e dos fantasmas
    private static int pacmanRow = 0;
    private static int pacmanCol = 0;
    private static int[] ghostRows = new int[4];
    private static int[] ghostCols = new int[4];

    // Direção do movimento do Pac-Man
    private static int pacmanDirection = KeyEvent.VK_UP; // Inicialmente para cima

    // Tabuleiro representado como uma matriz de caracteres
    private static char[][] board = new char[ROWS][COLS];

    // Componentes gráficos
    private JPanel panel;
    private JLabel[][] labels;

    public Pacman() {
        initializeBoard();
        placePacman();
        placeGhosts();

        setTitle("Pac-Man");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel(new GridLayout(ROWS, COLS));
        labels = new JLabel[ROWS][COLS];

        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                labels[i][j] = new JLabel(String.valueOf(board[i][j]), SwingConstants.CENTER);
                panel.add(labels[i][j]);
            }
        }

        add(panel);
        addKeyListener(this);
        setFocusable(true);
        setVisible(true);

        // Inicia o loop de jogo
        gameLoop();
    }

    // Inicializa o tabuleiro com pontos, paredes e espaços vazios
    private static void initializeBoard() {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (i == 0 || i == ROWS - 1 || j == 0 || j == COLS - 1) {
                    board[i][j] = WALL_CHAR; // Bordas do tabuleiro
                } else {
                    board[i][j] = EMPTY_CHAR; // Espaços vazios no interior do tabuleiro
                }
            }
        }
        // Adiciona alguns pontos aleatórios
        Random random = new Random();
        for (int i = 0; i < 5; i++) {
            int row = random.nextInt(ROWS - 2) + 1; // Ignora as bordas do tabuleiro
            int col = random.nextInt(COLS - 2) + 1;
            if (board[row][col] == EMPTY_CHAR) {
                board[row][col] = POINT_CHAR;
            }
        }
    }

    // Coloca o Pac-Man em uma posição inicial aleatória
    private static void placePacman() {
        Random random = new Random();
        do {
            pacmanRow = random.nextInt(ROWS - 2) + 1; // Ignora as bordas do tabuleiro
            pacmanCol = random.nextInt(COLS - 2) + 1;
        } while (board[pacmanRow][pacmanCol] != EMPTY_CHAR);
        board[pacmanRow][pacmanCol] = PACMAN_CHAR;
    }

    // Coloca os fantasmas em posições iniciais aleatórias
    private static void placeGhosts() {
        Random random = new Random();
        for (int i = 0; i < 4; i++) {
            do {
                ghostRows[i] = random.nextInt(ROWS - 2) + 1; // Ignora as bordas do tabuleiro
                ghostCols[i] = random.nextInt(COLS - 2) + 1;
            } while (board[ghostRows[i]][ghostCols[i]] != EMPTY_CHAR);
            board[ghostRows[i]][ghostCols[i]] = GHOST_CHAR;
        }
    }

    // Atualiza a exibição do tabuleiro
    private void updateDisplay() {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                labels[i][j].setText(String.valueOf(board[i][j]));
            }
        }
    }

    // Movimenta o Pac-Man
    private static void movePacman() {
        int newRow = pacmanRow;
        int newCol = pacmanCol;

        // Move o Pac-Man na direção atual
        switch (pacmanDirection) {
            case KeyEvent.VK_UP:
                newRow--;
                break;
            case KeyEvent.VK_DOWN:
                newRow++;
                break;
            case KeyEvent.VK_LEFT:
                newCol--;
                break;
            case KeyEvent.VK_RIGHT:
                newCol++;
                break;
        }

        // Verifica se o movimento é válido
        if (isValidMove(newRow, newCol)) {
            if (board[newRow][newCol] == POINT_CHAR) {
                System.out.println("Ponto capturado!");
                board[newRow][newCol] = EMPTY_CHAR;
            }
            board[pacmanRow][pacmanCol] = EMPTY_CHAR;
            pacmanRow = newRow;
            pacmanCol = newCol;
            board[pacmanRow][pacmanCol] = PACMAN_CHAR;

            // Verifica se todos os pontos foram capturados
            if (checkVictory()) {
                JOptionPane.showMessageDialog(null, "Você venceu!", "Parabéns", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            }
        } else {
            // Verifica se houve colisão com um fantasma
            if (board[newRow][newCol] == GHOST_CHAR) {
                JOptionPane.showMessageDialog(null, "Você perdeu!", "Game Over", JOptionPane.INFORMATION_MESSAGE);
                System.exit(0);
            } else {
                System.out.println("Movimento inválido!");
            }
        }
    }

    // Verifica se todos os pontos foram capturados
    private static boolean checkVictory() {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                if (board[i][j] == POINT_CHAR) {
                    return false; // Ainda há pontos no tabuleiro
                }
            }
        }
        return true; // Todos os pontos foram capturados
    }

    // Verifica se um movimento é válido para o Pac-Man
    private static boolean isValidMove(int row, int col) {
        return row >= 0 && row < ROWS && col >= 0 && col < COLS && board[row][col] != WALL_CHAR;
    }

    // Movimenta os fantasmas
    private static void moveGhosts() {
        Random random = new Random();
        for (int i = 0; i < 4; i++) {
            int direction = random.nextInt(4); // 0: up, 1: left, 2: down, 3: right
            int newRow = ghostRows[i];
            int newCol = ghostCols[i];
            switch (direction) {
                case 0:
                    newRow--;
                    break;
                case 1:
                    newCol--;
                    break;
                case 2:
                    newRow++;
                    break;
                case 3:
                    newCol++;
                    break;
            }
            if (isValidGhostMove(newRow, newCol)) {
                board[ghostRows[i]][ghostCols[i]] = EMPTY_CHAR;
                ghostRows[i] = newRow;
                ghostCols[i] = newCol;
                board[ghostRows[i]][ghostCols[i]] = GHOST_CHAR;
            }
        }
    }

    // Verifica se um movimento é válido para um fantasma
    private static boolean isValidGhostMove(int row, int col) {
        return row >= 0 && row < ROWS && col >= 0 && col < COLS && board[row][col] != PACMAN_CHAR
                && board[row][col] != WALL_CHAR;
    }

    // Loop principal do jogo
    private void gameLoop() {
        while (true) {
            movePacman();
            moveGhosts();
            updateDisplay();
            try {
                Thread.sleep(500); // Intervalo de atualização (meio segundo)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // Atualiza a direção do Pac-Man de acordo com a tecla pressionada
        int key = e.getKeyCode();
        switch (key) {
            case KeyEvent.VK_UP:
            case KeyEvent.VK_DOWN:
            case KeyEvent.VK_LEFT:
            case KeyEvent.VK_RIGHT:
                pacmanDirection = key;
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    public static void main(String[] args) {
        new Pacman();
    }
}
