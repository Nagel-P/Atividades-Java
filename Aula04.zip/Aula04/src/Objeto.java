public class Objeto {
    String nome;
    String cor;
    String local;

    @Override
    public String toString() {

        String txt = "Nome: " + nome + "\nCor: " + cor + "\nLocal: " + local;
        return txt;
    }
}
