public class Aula04 {

    public static void main(String[] args) {
        exVetObj();
    }

    public static void ex00() {
        int valor;

        do {
            System.out.print("\n\n Informe um valor entre 2 e 10: ");
            valor = Console.lerInt();
        } while (valor < 2 || valor > 10);

        int[] vetor = new int[valor];
        System.out.println("\nIniciando leitura do vetor.\n");

        for (int i = 0; i < vetor.length; i++) {
            System.out.print("Digite o " + i + " número: ");
            vetor[i] = Console.lerInt();
        }

        System.out.print("\nVetor gerado: ");
        for (int i = 0; i < vetor.length; i++) {
            System.out.print("[" + vetor[i] + "], ");
        }
        System.out.println("\n");
    }

    public static void exMatriz() {
        System.out.println("\n\nExemplo Matriz.");

        int[][] matriz = new int[3][3];

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("Informe o valor [" + i + "] | [" + j + "]: ");
                matriz[i][j] = Console.lerInt();
            }
        }
        System.out.println("\nExibindo matriz gerada.\n");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("[" + matriz[i][j] + "]\t");

            }
            System.out.println();
        }
        System.out.println("\n");
    }

    public static void exObj() {

        Objeto obj = new Objeto();
        System.out.print("\n\nInforme nome: ");
        obj.nome = Console.lerString();
        System.out.print("Informe cor: ");
        obj.cor = Console.lerString();
        System.out.print("Informe local: ");
        obj.local = Console.lerString();

        System.out.println("\nObjeto.\n");
        System.out.println(obj.toString() + "\n");

    }

    public static void exVetObj() {

        Objeto[] vetorObj = new Objeto[3];

        for (int i = 0; i < vetorObj.length; i++) {
            vetorObj[i] = new Objeto();
            System.out.print("\nInforme " + (i + 1) + "° nome: ");
            vetorObj[i].nome = Console.lerString();
            System.out.print("Informe " + (i + 1) + "° cor: ");
            vetorObj[i].cor = Console.lerString();
            System.out.print("Informe " + (i + 1) + "° local: ");
            vetorObj[i].local = Console.lerString();
        }
        System.out.println("\n");
        for (int i = 0; i < vetorObj.length; i++) {
            System.out.println("Objeto " + (i + 1) + "\n");
            System.out.print(vetorObj[i].toString() + "\n\n");

        }
    }

}