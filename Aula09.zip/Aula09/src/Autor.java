import java.util.ArrayList;
import java.util.List;

public class Autor {

    private String nome;
    private List<Livro> livros;

    public Autor(String nome) {
        this.nome = nome;
        livros = new ArrayList<>();
    }

    public void addLivro(Livro livro) {
        livros.add(livro);
        System.out.println("\nLivro adicionado: " + livro);
    }

    public void rmvLivro(Livro livro) {
        livros.remove(livro);
        System.out.println("\nLivro removido: " + livro);
    }

    @Override
    public String toString() {
        String txt = "Autor: " + nome;
        txt += "\nlivros:\n";

        for (Livro temp : livros) {
            txt += temp.toString();
        }
        return txt;
    }

}
