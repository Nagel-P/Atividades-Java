public class Aula09 {
    public static void main(String[] args) {
        System.out.println("");
        arrayList();

        associacao();

    }

    private static void associacao() {
        Carro c1 = new Carro("Fiat", "Uno", 1980);
        System.out.println("\n" + c1 + "\n");

        Carro c2 = new Carro("Fiat", "Argo", 2020);

        Dono d1 = new Dono("Adam Sandler", c1);
        System.out.println("\n" + d1 + "\n");

        d1.setCarro(c2);

        d1.getCarro().setModelo("Marea Turbo");
        d1.getCarro().setAno(1998);

        System.out.println("\n" + d1 + "\n");

        Carro c3 = new Carro(c1.getMontadora(), c1.getModelo(), c1.getAno());
        c3.setAno(1985);
        System.out.println("\n" + c3 + "\n");

    }

    private static void arrayList() {

        Livro l1 = new Livro("Cronica dos Aneis", "Fantasia");
        Livro l2 = new Livro("Senhor de Narnia", "Fantasia");
        Livro l3 = new Livro("Duna", "Sci-fi");
        Livro l4 = new Livro("Entre o Cavalo e Lobo", "Auto-ajuda");
        Livro l5 = new Livro("Com a Faca na Mão e a Espada na outra", "Auto-ajuda");

        Autor a1 = new Autor("Adam Sandler");
        a1.addLivro(l1);
        a1.addLivro(l2);

        Autor a2 = new Autor("Escritor Anonimo");
        a2.addLivro(l3);

        Autor a3 = new Autor("João");
        a3.addLivro(l4);
        a3.addLivro(l5);

        System.out.println("\n");
        System.out.println(a1);
        System.out.println("\n");
        System.out.println(a2);
        System.out.println("\n");
        System.out.println(a3);
        System.out.println("\n");

        System.out.println("Livro " + l2 + " removido da lista de libro");

        a1.rmvLivro(l2);
        System.out.println("\n");
        System.out.println(a1);
        System.out.println("\n");
    }
}
