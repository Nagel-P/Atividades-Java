public class Carro {

    private String montadora;
    private String modelo;
    private int ano;

    public Carro(String montadora, String modelo, int ano) {
        this.montadora = montadora;
        this.modelo = modelo;
        this.ano = ano;

    }

    public String getMontadora() {
        return montadora;
    }

    public void setMontadora(String montadora) {
        this.montadora = montadora;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    @Override
    public String toString() {
        String txt = "Carro: " + montadora + " " + modelo + "\nAno: " + ano;
        return txt;
    }
}
