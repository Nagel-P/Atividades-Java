import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class App {
    private static String nomeUnit = " ";
    private static int hpMax;
    private static int hpAtual;
    private static int cura;
    private static int dano;
    private static boolean hpMaxDefinido = false;
    private static boolean nomeUnitDefinido = false;

    public static void main(String[] args) {
        // Criar uma janela Swing
        JFrame frame = new JFrame("Calculador de HP RPG");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 700);

        // Criar um painel para conter os componentes
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2)); // Define um layout de grade 5x2

        JLabel nomeUnitLabel = new JLabel("    Nome: " + nomeUnit);
        panel.add(nomeUnitLabel);

        // Criar JTextField para inserir "nomeUnit"
        JTextField nomeUnitField = new JTextField();
        panel.add(nomeUnitField);

        // Adicionar JLabel para "hpMax"
        JLabel hpMaxLabel = new JLabel("    Vida Maxima: " + hpMax);
        panel.add(hpMaxLabel);

        // Criar JTextField para inserir "hpMax"
        JTextField hpMaxField = new JTextField();
        panel.add(hpMaxField);

        // Adicionar JLabel para "hpAtual"
        JLabel hpAtualLabel = new JLabel("    Vida Atual:");
        panel.add(hpAtualLabel);

        // Criar JTextField para exibir "hpAtual"
        JTextField hpAtualField = new JTextField();
        hpAtualField.setEditable(false); // Impede que seja editado diretamente
        panel.add(hpAtualField);

        // Adicionar JLabel para "cura"
        JLabel curaLabel = new JLabel("    Cura:");
        panel.add(curaLabel);

        // Criar JTextField para inserir "cura"
        JTextField curaField = new JTextField();
        panel.add(curaField);

        // Adicionar JLabel para "dano"
        JLabel danoLabel = new JLabel("    Dano:");
        panel.add(danoLabel);

        // Criar JTextField para inserir "dano"
        JTextField danoField = new JTextField();
        panel.add(danoField);

        nomeUnitField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!nomeUnitDefinido) {
                    nomeUnit = (nomeUnitField.getText());
                    nomeUnitLabel.setText("    Nome: " + nomeUnit);
                    nomeUnitField.setEditable(false); // Desativar hpMaxField
                    nomeUnitDefinido = true;
                }

            }
        });

        // Adicionar um listener para o JTextField "hpMaxField"
        hpMaxField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!hpMaxDefinido) {
                    // Obter o valor de "hpMax" do JTextField e converter para int
                    hpMax = Integer.parseInt(hpMaxField.getText());
                    if (hpMax <= 0) {
                        JOptionPane.showMessageDialog(frame, "hpMax deve ser maior que 0");
                        hpMax = 1; // Definir um valor padrão
                    }
                    // Atualizar o texto do JLabel "hpMaxLabel"
                    hpMaxLabel.setText("    Vida Maxima: " + hpMax);
                    hpMaxField.setEditable(false); // Desativar hpMaxField
                    hpMaxDefinido = true;
                    // Definir hpAtual como hpMax
                    hpAtual = hpMax;
                    hpAtualField.setText(String.valueOf(hpAtual));
                } else {
                    JOptionPane.showMessageDialog(frame, "hpMax já foi definido e não pode ser alterado.");
                }
            }
        });

        // Adicionar um listener para o JTextField "curaField"
        curaField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obter o valor de "cura" do JTextField e converter para int
                cura = Integer.parseInt(curaField.getText());
                // Verificar se hpAtual é menor ou igual a hpMax antes de aplicar a cura
                if (hpAtual <= hpMax) {
                    // Somar "cura" ao valor de "hpAtual"
                    hpAtual += cura;
                    // Verificar se hpAtual ultrapassou hpMax
                    if (hpAtual > hpMax) {
                        hpAtual = hpMax; // Limitar hpAtual a hpMax
                    }
                    // Atualizar o texto do JTextField "hpAtualField"
                    hpAtualField.setText(String.valueOf(hpAtual));
                }
                // Limpar o campo de texto "curaField"
                curaField.setText("");
            }
        });

        // Adicionar um listener para o JTextField "danoField"
        danoField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obter o valor de "dano" do JTextField e converter para int
                dano = Integer.parseInt(danoField.getText());
                // Verificar se hpAtual é maior que 0 antes de aplicar o dano
                if (hpAtual > 0) {
                    // Subtrair "dano" do valor de "hpAtual"
                    hpAtual -= dano;
                    // Verificar se hpAtual se tornou negativo
                    if (hpAtual < 0) {
                        hpAtual = 0; // Limitar hpAtual a 0
                    }
                    // Atualizar o texto do JTextField "hpAtualField"
                    hpAtualField.setText(String.valueOf(hpAtual));
                }
                // Limpar o campo de texto "danoField"
                danoField.setText("");
            }
        });

        // Adicionar os componentes ao painel
        panel.add(nomeUnitLabel);
        panel.add(nomeUnitField);
        panel.add(hpMaxLabel);
        panel.add(hpMaxField);
        panel.add(hpAtualLabel);
        panel.add(hpAtualField);
        panel.add(curaLabel);
        panel.add(curaField);
        panel.add(danoLabel);
        panel.add(danoField);

        // Adicionar o painel à janela
        frame.add(panel);

        // Exibir a janela
        frame.setVisible(true);
    }
}
