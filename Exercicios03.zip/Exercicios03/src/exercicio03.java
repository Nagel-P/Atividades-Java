import java.util.Scanner;

public class exercicio03 {

    public static Scanner leitor = new Scanner(System.in);

    public static void main(String[] args) {
        ex01();
    }

    public static void ex01() {

        double[] numeros = new double[5];
        double soma = 0;

        System.out.println("\n");

        // Lendo os números digitados pelo usuário e somando-os
        for (int i = 0; i < 5; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            numeros[i] = leitor.nextDouble();
            soma += numeros[i];
        }

        // Calculando a média
        double media = soma / 5;

        // Criando o vetor para armazenar os resultados
        String[] resultado = new String[5];

        // Verificando se cada número é menor, igual ou maior que a média
        for (int i = 0; i < 5; i++) {
            if (numeros[i] < media) {
                resultado[i] = "menor que a média";
            } else if (numeros[i] == media) {
                resultado[i] = "igual à média";
            } else {
                resultado[i] = "maior que a média";
            }
        }

        // Apresentando os resultados na tela
        System.out.println("\nResultados:");
        for (int i = 0; i < 5; i++) {
            System.out.println(numeros[i] + " é " + resultado[i]);
        }

    }

}
