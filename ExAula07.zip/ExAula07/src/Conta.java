public class Conta {

    private int num;
    private String nome;
    private float saldo;

    public Conta(int num, String nome, float saldo) {
        this.num = num;
        this.nome = nome;
        this.saldo = saldo;
    }

    public int getNum() {
        return num;
    }

    public String getNome() {
        return nome;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public void getNome(String nome) {
        this.nome = nome;
    }

    public void getSaldo(float saldo) {
        this.saldo = saldo;
    }

    public void depositar(float valor) {
        saldo = saldo + valor;
        saldo();

    }

    public void sacar(float valor) {
        saldo = saldo - valor;
        saldo();
    }

    public void saldo() {
        System.out.println("Saldo da conta: " + saldo);
    }

}
