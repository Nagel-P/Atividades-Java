public class Jogador {
    private String name;
    private int points;
    private int level;

    public Jogador(String name, int points, int level) {
        this.name = name;
        this.points = points;
        this.level = level;
    }

    public String getname() {
        return name;
    }

    public int getPoints() {
        return points;
    }

    public int getlevel() {
        return level;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void getNome(int points) {
        this.points = points;
    }

    public void getSaldo(int level) {
        this.level = level;
    }

    public void pointsUp(int value) {
        points = points + value;
        info();

    }

    public void levelUp(int value) {
        level = level + value;
        info();
    }

    public void info() {
        System.out.println("Name: " + name + "\nPoints: " + points + "\nLevel: " + level + "\n");
    }

}
