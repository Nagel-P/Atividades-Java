import java.util.List;

public class Exercicios {
    public static void main(String[] args) {

        int exemplo;

        System.out.print("\n\nInforme um exercicio(0 | Encerrar): ");
        exemplo = Console.lerInt();

        switch (exemplo) {
            case 0:
                System.out.println("O programa sera finalizado.");
                break;
            case 1:
                ex01();
                break;
            case 2:
                ex02();
                break;
            case 3:
                ex03();
                break;
            case 4:
                ex04();
            case 5:
                ex05();
                break;
            case 6:
                ex06();
                break;
            default:
                System.out.println("Valor não operavel!");
                main(args);
                break;
        }
    }

    public static void ex01() {
        int num1, num2;
        char calculadora;

        System.out.println("\n\n==== CALCULADORA ====\n\nInforme a operação (+) (-) (*) (/)");
        calculadora = Console.lerChar();

        switch (calculadora) {
            case '+':
                System.out.println("Infome dois valores inteiros.");
                num1 = Console.lerInt();
                num2 = Console.lerInt();

                System.out.println("\n" + num1 + "+" + num2 + "=" + (num1 + num2) + "\n\n");
                break;
            case '-':
                System.out.println("Infome dois valores inteiros.");
                num1 = Console.lerInt();
                num2 = Console.lerInt();

                System.out.println("\n" + num1 + "-" + num2 + "=" + (num1 - num2) + "\n\n");
                break;
            case '*':
                System.out.println("Infome dois valores inteiros.");
                num1 = Console.lerInt();
                num2 = Console.lerInt();

                System.out.println("\n" + num1 + "*" + num2 + "=" + (num1 * num2) + "\n\n");
                break;
            case '/':
                System.out.println("Infome dois valores inteiros.");
                num1 = Console.lerInt();
                num2 = Console.lerInt();

                if (num2 == 0) {
                    System.out.println("Não pode dividir por 0 burro!!");
                } else {
                    System.out.println("\n" + num1 + "/" + num2 + "=" + (num1 / num2) + "\n\n");
                }
                break;
            default:
                System.out.println("\nOperação não existente.");
                ex01();
                break;
        }
    }

    public static void ex02() {
        System.out.println("\n\n==== Biblioteca Virtual ====\n\n");

        Livro l1 = new Livro();

        System.out.println("\nCadastrar livro.");

        System.out.print("Titulo: ");
        l1.titulo = Console.lerString();
        System.out.print("Autor: ");
        l1.autor = Console.lerString();
        System.out.print("Ano: ");
        l1.ano = Console.lerInt();

        Livro l2 = new Livro("Cada um Tem a Gêmea que Merce", "Adam Sandler", 2005);
        Livro l3 = new Livro("Cronicas dos Aneis", "Senhor de Narnia", 2030);

        System.out.println("\nExibir Livro.\n");

        System.out.println(l1.toString());
        System.out.println(l2.toString());
        System.out.println(l3.toString());
    }

    public static void ex03() {
        int op;
        Conta c1 = new Conta(412, "Jorge Vasconcelos", 1000);
        float valor;

        System.out.print("\n\nSelecionar método (1 | sacar) (2 | depositar) (3 | consultar saldo)\nOpção: ");
        op = Console.lerInt();

        switch (op) {
            case 1:
                System.out.print("Informe valor de saque: ");
                valor = Console.lerFloat();
                c1.sacar(valor);
                break;
            case 2:
                System.out.print("Informe valor de deposito: ");
                valor = Console.lerFloat();
                c1.depositar(valor);
                break;
            case 3:
                c1.saldo();
                break;
            default:
                System.out.println("Errado BURRO!");
                break;
        }
    }

    public static void ex04() {
        int op;
        System.out.println("\n\n==== Player System ====\n\n");
        int value;

        Jogador j1 = new Jogador("DarkBladeBr234", 6774, 6);

        System.out.print("\nSelect method (1 | Add Points) (2 | Level up) (3 | Info Player)\nOption: ");
        op = Console.lerInt();

        switch (op) {
            case 1:
                System.out.print("Add the amount of score points: ");
                value = Console.lerInt();
                j1.pointsUp(value);
                break;
            case 2:
                System.out.print("Add level up: ");
                value = Console.lerInt();
                j1.levelUp(value);
                break;
            case 3:
                j1.info();
                break;
            default:
                System.out.println("\nOption didn't exists!!\n");
                break;
        }
    }

    public static void ex05() {

        System.out.println("\n\n==== Carro ====\n\n");

        Carro c1 = new Carro("Fiat", "Uno", 1980, 140, 30);
        c1.acelerar(50);
        c1.frear(20);
        c1.exibirInformacoes();
    }

    public static void ex06() {

        System.out.println("\n\n==== Agenta ====\n\n");

        Contato c1 = new Contato("Jason", "111111111");
        Contato c2 = new Contato("Maria", "222222222");
        Contato c3 = new Contato("Jason", "333333333");
        Contato c4 = new Contato("Adam", "444444444");
        Contato c5 = new Contato("Sandler", "555555555");
        Contato c6 = new Contato("Jason", "666666666");

        Agenda agenda = new Agenda();
        agenda.adicionar(c1);
        agenda.adicionar(c2);
        agenda.adicionar(c3);
        agenda.adicionar(c4);
        agenda.adicionar(c5);
        agenda.adicionar(c6);

        List<Contato> encontrados = agenda.buscar("Jason");
        if (encontrados.isEmpty()) {
            System.out.println("Nenhum contato encontrado.");
        } else {
            System.out.println("Contatos encontrados com o nome 'Jason':");
            for (Contato contato : encontrados) {
                System.out.println(contato);
            }
        }
    }

}
