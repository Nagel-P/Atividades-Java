public class Livro {
    String autor;
    String titulo;
    int ano;

    public Livro(String titulo, String autor, int ano) {
        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano;

    }

    public Livro() {
    }

    @Override
    public String toString() {
        String txt = "Titulo: " + titulo + "\nAutor: " + autor + "\nAno: " + ano + "\n";
        return txt;
    }
}
