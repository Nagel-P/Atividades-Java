public class Carro {

    private String marca;
    private String modelo;
    private int ano;
    private double velocidade;
    private double frenagem;
    private double aceleracao;

    public Carro(String marca, String modelo, int ano, double aceleracao, double reducaoVelocidade) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.velocidade = 0;
        this.aceleracao = aceleracao;
        this.frenagem = reducaoVelocidade;
    }

    public void acelerar(double aceleracao) {
        velocidade += aceleracao;
    }

    public void frear(double frenagem) {
        if (velocidade > frenagem) {
            velocidade -= frenagem;
        } else {
            velocidade = 0;
        }
    }

    public void exibirInformacoes() {
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Ano: " + ano);
        System.out.println("Velocidade de aceleração: " + aceleracao + " km/h");
        System.out.println("Velocidade de frenagem: " + frenagem + " km/h");
        System.out.println("Velocidade Atual: " + velocidade + " km/h");
    }
}