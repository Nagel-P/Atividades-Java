public class Aula05 {

    public static void main(String[] args) {
        System.out.println("\n\n");

        exCarro();

        System.out.println("\n\n");
    }

    public static void exPessoa() {
        Pessoa p1 = new Pessoa();
        p1.nome = "Adam Sandler";
        p1.idade = 57;

        System.out.println("\n\n === Dados de p1 === \nNome: " + p1.nome + "\nIdade: " + p1.idade);

        Pessoa p2 = new Pessoa();
        System.out.print("\ninforme nome p2: ");
        p2.nome = Console.lerString();
        System.out.print("informe idade p2: ");
        p2.idade = Console.lerInt();

        System.out.println("\nnome: " + p2.nome + "\nidade: " + p2.idade);

        Pessoa p3;
        new Pessoa();
        p3 = p2;

        p3.idade = 25;

        System.out.print("\nidade p2: " + p2.idade + "\nidade p3: " + p3.idade);

        Pessoa p4 = new Pessoa();
        p4.nome = p1.nome;
        p4.idade = p1.idade;

        System.out.print("\nnome p4: " + p4.nome + "\nidade p4: " + p4.idade);

        p4.nome = "Robert";

        System.out.println("\nnome p1: " + p1.nome);
        System.out.println("\nnome p4: " + p4.nome);

        System.out.println("\n");
    }

    public static void exCarro() {

        Carro c1 = new Carro();

        System.out.print("modelo: ");
        c1.modelo = Console.lerString();
        System.out.print("ano: ");
        c1.ano = Console.lerInt();
        System.out.print("cor: ");
        c1.cor = Console.lerString();
        System.out.println("\n");
        System.out.println(c1.toString());
        System.out.println("\n");
        Carro c2 = new Carro();
        System.out.println(c2.toString());

        System.out.println("\n");
        c1.ligar();
        c2.ligar();
        System.out.println("\n");
        c1.desligar();
        c2.desligar();
        System.out.println("\n\n");

        Carro c3 = new Carro("Fusca", 1970, "azul");
        System.out.println(c3.toString());
        System.out.println("\n");
        c3.modelo = "fiat uno";
        System.out.println(c3.toString());

        System.out.println("\n");
        System.out.print("modelo: ");
        String modelo = Console.lerString();
        System.out.print("ano: ");
        int ano = Console.lerInt();
        System.out.print("cor: ");
        String cor = Console.lerString();
        System.out.println("");

        Carro c4 = new Carro(modelo, ano, cor);

        System.out.println(c4.toString());
    }

}