public class Carro {
    String modelo;
    int ano;
    String cor;

    public Carro() {
        modelo = "celta";
        ano = 2012;
        cor = "vermelho";
    }

    public Carro(String modelo, int ano, String cor) {
        this.modelo = modelo;
        this.ano = ano;
        this.cor = cor;
    }

    @Override
    public String toString() {
        String txt = "Carro: " + modelo + "\nAno: " + ano + "\nCor: " + cor;
        return txt;
    }

    public void ligar() {
        System.out.println("o carro " + modelo + " " + ano + " esta ligado.");
    }

    public void desligar() {
        System.out.println("o carro " + modelo + " " + ano + " esta desligado.");
    }
}
